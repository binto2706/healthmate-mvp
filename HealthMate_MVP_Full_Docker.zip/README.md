# HealthMate - MVP (local)

## Chạy với Docker
1. `docker compose up --build`
2. Backend: http://localhost:4000
3. Frontend: http://localhost:5173

## Chạy local (không Docker)
- Server: `cd server && npm install && node index.js`
- Client: `cd client && npm install && npm run dev`
