import React from 'react'
import ScanPrescription from './components/ScanPrescription'

export default function App() {
  return (
    <div style={{padding:20,fontFamily:'Arial'}}>
      <h1>HealthMate - MVP (Demo)</h1>
      <ScanPrescription />
    </div>
  )
}